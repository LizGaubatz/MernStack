import './App.css';
import Pokemon from './components/Pokemon';

function App() {

  return (
    <div>
      <Pokemon />
    </div>
  );
}

export default App;

import React from 'react';

const Error = () => {
    return (<div>
        <img src="https://static1.moviewebimages.com/wordpress/wp-content/uploads/2021/12/star-wars-revenge-of-the-sith-obi-wan-kenobi-ewan-mcgregor-1223302.jpg?q=50&fit=contain&w=767&h=401&dpr=1.5" alt="These are not the droids you are looking for" />
    </div>
    )
};

export default Error;
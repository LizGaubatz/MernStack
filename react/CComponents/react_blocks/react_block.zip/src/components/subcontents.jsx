import React, { Component } from "react";

class Subcontents extends Component {
    render() {
        return (
            <div className="subcontents"></div>);
    }
}

export default Subcontents;


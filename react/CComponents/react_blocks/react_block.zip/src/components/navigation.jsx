import React, { Component } from "react";

class Navigation extends Component {
    render() {
        return (
            <div className="navigation"></div>);
    }
}

export default Navigation;
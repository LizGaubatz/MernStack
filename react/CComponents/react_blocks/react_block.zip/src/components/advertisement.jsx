import React, { Component } from "react";

class Advertisement extends Component {
    render() {
        return (
            <div className="advertisement"></div>);
    }
}

export default Advertisement;
import './App.css';
import UserForm from '../../hook_form/src/components/UserForm';


function App() {
  return (
    <div className="App">
      <UserForm/>
    </div>
  );
}

export default App;
